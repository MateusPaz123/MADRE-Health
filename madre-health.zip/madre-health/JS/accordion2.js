// Navegar para a seção "Como Funciona"
document.getElementById('btn-como-funciona').addEventListener('click', function() {
    window.location.href = '#como-funciona'; // Vai para a seção "Como Funciona"
});

// Navegar para a seção "Ajuda"
document.getElementById('btn-ajuda').addEventListener('click', function() {
    window.location.href = '#ajuda'; // Vai para a seção "Ajuda"
});

// Navegar para a seção "Sobre"
document.getElementById('btn-sobre').addEventListener('click', function() {
    window.location.href = '#sobre'; // Vai para a seção "Sobre"
});